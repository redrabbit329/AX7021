#!/bin/sh
Cur_Dir=$(pwd)
echo $Cur_Dir
export LD_LIBRARY_PATH=$Cur_Dir/opencv_lib_zynq/lib:$LD_LIBRARY_PATH



