#!/bin/sh
source qt_env_set.sh
source opencv_env_set.sh


