#!/bin/sh
Cur_Dir=$(pwd)
echo $Cur_Dir
export QTDIR=$Cur_Dir/qt_lib
export QT_QPA_FONTDIR=$QTDIR/lib/fonts
export QT_QPA_PLATFORM_PLUGIN_PATH=$QTDIR/plugins/
export LD_LIBRARY_PATH=$QTDIR/lib:$LD_LIBRARY_PATH
export PATH=$QTDIR/bin:$PATH
export QT_QPA_PLATFORM=linuxfb


