#!/bin/sh
Cur_Dir=$(pwd)
echo $Cur_Dir
export QTDIR=$Cur_Dir/qt
export CVDIR=$Cur_Dir/cv
export FFMPEGDIR=$Cur_Dir/ffmpeg
export QT_QPA_FONTDIR=$QTDIR/lib/fonts
export QT_QPA_PLATFORM_PLUGIN_PATH=$QTDIR/plugins/
export LD_LIBRARY_PATH=$QTDIR/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$CVDIR/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$FFMPEGDIR/lib:$LD_LIBRARY_PATH
export PATH=$QTDIR/bin:$PATH
export QT_QPA_PLATFORM=linuxfb
#export QT_LOGGING_RULES=qt.qpa.input=true


